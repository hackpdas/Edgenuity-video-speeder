// Listen for messages from the background script
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    // If the request is to change the speed of the video
    if (request.type === 'changeSpeed') {
      // Get the current speed of the video
      let speed = document.querySelector("video").playbackRate;
  
      // Increase the speed by 0.25
      speed += 0.50;
  
      // Set the new speed of the video
      document.querySelector("video").playbackRate = speed;
  
      // Return the new speed to the background
  