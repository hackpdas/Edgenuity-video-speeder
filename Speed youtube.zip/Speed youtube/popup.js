// Get the speed up button and speed display elements
let speedUpButton = document.querySelector("#speedUp");
let speedDisplay = document.querySelector("#speedDisplay");

// Add a click event listener to the speed up button
speedUpButton.addEventListener("click", function () {
  // Send a message to the background script to change the speed of the video
  chrome.runtime.sendMessage({ type: "changeSpeed" }, function (response) {
    // Update the speed display with the new speed
    speedDisplay.innerText = `Current Speed: ${response.speed}x`;
  });
});
