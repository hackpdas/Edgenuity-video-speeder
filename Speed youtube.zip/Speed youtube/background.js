// Listen for messages from the popup
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    // If the request is to change the speed of the video
    if (request.type === 'changeSpeed') {
      // Get the current tab
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        // Send a message to the content script in the current tab
        chrome.tabs.sendMessage(tabs[0].id, { type: 'changeSpeed' }, function (response) {
          // Return the new speed to the popup
          sendResponse({ speed: response.speed });
        });
      });
    }
    return true;
  });
  